package treningdagbok;

public class StaticMethods {
	
	public static String toQuote(String s) {
		return "\"" +s+"\"";
	}

}
